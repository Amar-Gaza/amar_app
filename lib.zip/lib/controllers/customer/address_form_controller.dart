import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

import '../../core/network/api_failure.dart';
import '../../core/constants/api_query.dart';
import '../../data/models/catalog/picked_location.dart';
import '../../data/models/masar/masar_models.dart';
import '../../data/models/requests/address_request.dart';
import '../../data/services/customer/address_service.dart';
import '../../data/services/shared/device_location_service.dart';

/// New or edited address: device position + label + details.
class AddressFormController extends GetxController {
  AddressFormController(
      this._addresses,
      this._location, {
        this.existing,
        this.initial,
        this.useCurrentLocation = false,
      });

  final AddressService _addresses;
  final DeviceLocationService _location;

  /// Set when editing (PUT /addresses/{id}).
  final Address? existing;
  final PickedLocation? initial;
  final bool useCurrentLocation;

  final TextEditingController label = TextEditingController();
  final TextEditingController details = TextEditingController();

  final RxBool isDefault = false.obs;
  final RxnDouble lat = RxnDouble();
  final RxnDouble lng = RxnDouble();

  final RxBool isLocating = false.obs;
  final Rxn<LocationIssue> locationIssue = Rxn<LocationIssue>();
  final RxBool addressUnavailable = false.obs;
  final RxBool isResolving = false.obs;
  final Rxn<ResolvedLocation> resolved = Rxn<ResolvedLocation>();

  int _revision = 0;

  final RxBool isSaving = false.obs;
  final Rxn<ApiFailure> failure = Rxn<ApiFailure>();
  final RxBool labelMissing = false.obs;

  String? _locationDetails;
  Worker? _locationWorker;

  bool get hasPosition => lat.value != null && lng.value != null;

  bool get isEditing => existing != null;

  @override
  void onInit() {
    super.onInit();

    _locationWorker = ever<String>(_location.languageCode, (_) {
      if (hasPosition) {
        setPosition(
          PickedLocation(
            lat: lat.value!,
            lng: lng.value!,
          ),
        );
      }
    });

    final address = existing;
    if (address == null) return;

    label.text = address.label ?? '';
    details.text = address.details ?? '';
    isDefault.value = address.isDefault;
    lat.value = address.lat;
    lng.value = address.lng;
  }

  @override
  void onReady() {
    super.onReady();

    if (isEditing) return;

    final point = initial ?? _location.currentPoint.value;

    if (useCurrentLocation || point == null) {
      locate();
    } else {
      setPosition(point);
    }
  }

  Future<void> locate() async {
    if (isLocating.value) return;

    final revision = _revision;
    isLocating.value = true;
    locationIssue.value = null;

    try {
      final position = await _location.current();

      if (isClosed || revision != _revision) return;

      await setPosition(
        PickedLocation(
          lat: position.latitude,
          lng: position.longitude,
        ),
      );
    } on LocationException catch (error) {
      if (!isClosed && revision == _revision) {
        locationIssue.value = error.issue;
      }
    } finally {
      if (!isClosed) isLocating.value = false;
    }
  }

  Future<void> setPosition(PickedLocation point) async {
    final revision = ++_revision;

    lat.value = point.lat;
    lng.value = point.lng;
    locationIssue.value = null;
    addressUnavailable.value = false;
    resolved.value = null;
    isResolving.value = true;

    _clearLocationDetailsIfAutomatic();

    try {
      final location = await _location.resolveAddress(point);

      if (isClosed || revision != _revision) return;

      resolved.value = location;
      _updateLocationDetails(location.label);
    } on LocationAddressException {
      if (!isClosed && revision == _revision) {
        addressUnavailable.value = true;
      }
    } finally {
      if (!isClosed && revision == _revision) {
        isResolving.value = false;
      }
    }
  }

  Future<bool> openSettings() => _location.openSettings();

  Future<bool> openLocationSettings() =>
      _location.openLocationSettings();

  void _updateLocationDetails(String value) {
    if (details.text.trim().isEmpty ||
        details.text == _locationDetails) {
      details.text = value;
      _locationDetails = value;
    }
  }

  void _clearLocationDetailsIfAutomatic() {
    if (_locationDetails != null &&
        details.text == _locationDetails) {
      details.clear();
    }

    _locationDetails = null;
  }

  /// Returns the created address, or null when validation or the server
  /// rejected it.
  Future<Address?> save() async {
    labelMissing.value = label.text.trim().isEmpty;

    if (labelMissing.value ||
        !hasPosition ||
        isSaving.value ||
        isLocating.value ||
        isResolving.value) {
      return null;
    }

    isSaving.value = true;
    failure.value = null;

    try {
      final request = AddressRequest(
        label: label.text.trim(),
        lat: lat.value!,
        lng: lng.value!,
        details: details.text.trim().isEmpty
            ? null
            : details.text.trim(),
        isDefault: isDefault.value,
      );

      final address = existing;

      final saved = address == null
          ? await _addresses.create(request)
          : await _addresses.update(address.id, request);

      _location.confirmPoint(
        PickedLocation(
          lat: saved.lat,
          lng: saved.lng,
        ),
        address: resolved.value,
      );

      return saved;
    } on ApiFailure catch (e) {
      failure.value = e;
      return null;
    } catch (_) {
      failure.value = const ApiFailure(
        code: ApiErrorCodes.serverError,
      );
      return null;
    } finally {
      isSaving.value = false;
    }
  }

  @override
  void onClose() {
    ++_revision;
    _locationWorker?.dispose();
    label.dispose();
    details.dispose();
    super.onClose();
  }
}