import 'dart:async';

import 'package:get/get.dart';

import '../../core/constants/app_defaults.dart';
import '../../core/constants/app_durations.dart';
import '../../data/models/catalog/picked_location.dart';
import '../../data/services/shared/device_location_service.dart';

/// Local map draft. Cancelling does not change the confirmed location.
class MapPickerController extends GetxController {
  MapPickerController(
      this._location,
      this.initial, {
        this.autoLocate = true,
      });

  final DeviceLocationService _location;
  final PickedLocation? initial;
  final bool autoLocate;

  late final Rx<PickedLocation> _point = (
      initial ??
          _location.currentPoint.value ??
          const PickedLocation(
            lat: AppDefaults.mapDefaultLat,
            lng: AppDefaults.mapDefaultLng,
          )
  ).obs;

  PickedLocation get point => _point.value;

  final Rxn<PickedLocation> located = Rxn<PickedLocation>();

  final RxBool isLocating = false.obs;
  final RxBool isResolving = false.obs;
  final RxBool hasSelection = false.obs;
  final RxBool isDragging = false.obs;
  final RxBool addressUnavailable = false.obs;

  final Rxn<ResolvedLocation> address = Rxn<ResolvedLocation>();
  final Rxn<LocationIssue> issue = Rxn<LocationIssue>();

  int _revision = 0;
  Timer? _debounce;
  Worker? _languageWorker;

  bool get canConfirm =>
      hasSelection.value &&
          !isLocating.value &&
          !isResolving.value &&
          !isDragging.value;

  @override
  void onInit() {
    super.onInit();

    hasSelection.value =
        initial != null ||
            _location.currentPoint.value != null;

    _languageWorker = ever<String>(
      _location.languageCode,
          (_) {
        if (hasSelection.value && !isDragging.value) {
          setPoint(point);
        }
      },
    );
  }

  @override
  void onReady() {
    super.onReady();

    if (hasSelection.value) {
      setPoint(point);
    } else if (autoLocate) {
      locate();
    }
  }

  void setPoint(PickedLocation value) {
    final revision = ++_revision;

    isDragging.value = false;
    isLocating.value = false;

    _point.value = value;
    hasSelection.value = true;

    issue.value = null;
    address.value = null;
    addressUnavailable.value = false;
    isResolving.value = true;

    _debounce?.cancel();

    _debounce = Timer(
      AppDurations.locationDebounce,
          () => _resolveAddress(value, revision),
    );
  }

  /// Invalidate GPS immediately when dragging starts.
  void beginManualSelection() {
    ++_revision;
    _debounce?.cancel();

    isDragging.value = true;
    isLocating.value = false;
    isResolving.value = false;

    address.value = null;
    addressUnavailable.value = false;
    issue.value = null;
  }

  Future<void> _resolveAddress(
      PickedLocation value,
      int revision,
      ) async {
    try {
      final result = await _location.resolveAddress(value);

      if (!isClosed && revision == _revision) {
        address.value = result;
      }
    } on LocationAddressException {
      if (!isClosed && revision == _revision) {
        addressUnavailable.value = true;
      }
    } finally {
      if (!isClosed && revision == _revision) {
        isResolving.value = false;
      }
    }
  }

  Future<void> locate() async {
    if (isLocating.value || isDragging.value) return;

    final revision = _revision;

    isLocating.value = true;
    issue.value = null;

    try {
      final position = await _location.current();

      if (isClosed || revision != _revision) return;

      final value = PickedLocation(
        lat: position.latitude,
        lng: position.longitude,
      );

      setPoint(value);
      located.value = value;
    } on LocationException catch (error) {
      if (!isClosed && revision == _revision) {
        issue.value = error.issue;
      }
    } finally {
      if (!isClosed && revision == _revision) {
        isLocating.value = false;
      }
    }
  }

  Future<bool> openSettings() => _location.openSettings();

  Future<bool> openLocationSettings() =>
      _location.openLocationSettings();

  @override
  void onClose() {
    ++_revision;
    _debounce?.cancel();
    _languageWorker?.dispose();

    super.onClose();
  }
}