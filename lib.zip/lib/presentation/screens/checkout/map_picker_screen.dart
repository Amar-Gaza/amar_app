import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../controllers/customer/map_picker_controller.dart';
import '../../../core/constants/app_defaults.dart';
import '../../../core/localization/location_issue_text.dart';
import '../../../core/theme/app_spacing.dart';

import '../../../data/models/catalog/picked_location.dart';
import '../../../data/services/shared/device_location_service.dart';

import '../../../l10n/app_localizations.dart';

import '../../widgets/checkout/bottom_action_bar.dart';
import '../../widgets/common/app_top_bar.dart';
import '../../widgets/common/info_banner.dart';
import '../../widgets/common/primary_button.dart';
import '../../widgets/common/square_icon_button.dart';
import '../../widgets/common/state_tone.dart';

/// Returns a point selected by tapping the map or dragging the marker.
class MapPickerScreen extends StatefulWidget {
  const MapPickerScreen({super.key});

  @override
  State<MapPickerScreen> createState() =>
      _MapPickerScreenState();
}

class _MapPickerScreenState
    extends State<MapPickerScreen> {
  final MapPickerController _picker =
  Get.find<MapPickerController>();

  final Completer<GoogleMapController> _map =
  Completer<GoogleMapController>();

  late final Worker _follow = ever(
    _picker.located,
    _moveTo,
  );

  @override
  void initState() {
    super.initState();
    _follow;
  }

  Future<void> _moveTo(PickedLocation? point) async {
    if (point == null) return;
    if (!_map.isCompleted || !mounted) return;

    final map = await _map.future;

    if (!mounted || point != _picker.point) return;

    await map.animateCamera(
      CameraUpdate.newLatLngZoom(
        LatLng(point.lat, point.lng),
        AppDefaults.mapZoom,
      ),
    );
  }

  @override
  void dispose() {
    _follow.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final start = _picker.point;

    return Scaffold(
      appBar: AppTopBar(
        title: l10n.mapPickerTitle,
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Obx(
                () => GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(
                  start.lat,
                  start.lng,
                ),
                zoom: AppDefaults.mapZoom,
              ),
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              onMapCreated: (map) {
                if (!_map.isCompleted) {
                  _map.complete(map);
                }

                _moveTo(_picker.point);
              },
              onTap: (point) {
                _picker.setPoint(
                  PickedLocation(
                    lat: point.latitude,
                    lng: point.longitude,
                  ),
                );
              },
              onLongPress: (point) {
                _picker.setPoint(
                  PickedLocation(
                    lat: point.latitude,
                    lng: point.longitude,
                  ),
                );
              },
              markers: {
                if (_picker.hasSelection.value)
                  Marker(
                    markerId: const MarkerId(
                      'selected-location',
                    ),
                    position: LatLng(
                      _picker.point.lat,
                      _picker.point.lng,
                    ),
                    draggable: true,
                    onDragStart: (_) {
                      _picker.beginManualSelection();
                    },
                    onDragEnd: (point) {
                      _picker.setPoint(
                        PickedLocation(
                          lat: point.latitude,
                          lng: point.longitude,
                        ),
                      );
                    },
                  ),
              },
            ),
          ),
          PositionedDirectional(
            start: AppSpacing.lg,
            end: AppSpacing.lg,
            bottom:
            AppSpacing.lg +
                AppSpacing.xl +
                AppSpacing.lg,
            child: Obx(() {
              final address = _picker.address.value;

              return InfoBanner(
                icon: LucideIcons.mapPin,
                tone: _picker.addressUnavailable.value
                    ? StateTone.warning
                    : StateTone.info,
                title:
                !_picker.hasSelection.value ||
                    _picker.isDragging.value
                    ? l10n.mapPickerTitle
                    : _picker.isResolving.value
                    ? l10n.addressLocating
                    : address?.label ??
                    l10n.locationAddressUnavailable,
              );
            }),
          ),
          PositionedDirectional(
            end: AppSpacing.lg,
            bottom: AppSpacing.lg,
            child: Obx(
                  () => SquareIconButton(
                icon: LucideIcons.locateFixed,
                tooltip: l10n.addressUseMyLocation,
                onPressed:
                _picker.isLocating.value ||
                    _picker.isDragging.value
                    ? null
                    : _picker.issue.value ==
                    LocationIssue.deniedForever
                    ? _picker.openSettings
                    : _picker.issue.value ==
                    LocationIssue.serviceDisabled
                    ? _picker.openLocationSettings
                    : _picker.locate,
              ),
            ),
          ),
          PositionedDirectional(
            top: AppSpacing.md,
            start: AppSpacing.lg,
            end: AppSpacing.lg,
            child: Obx(() {
              final issue = _picker.issue.value;

              if (issue == null) {
                return const SizedBox.shrink();
              }

              return InfoBanner(
                icon: LucideIcons.mapPin,
                tone: StateTone.warning,
                title: LocationIssueText.of(
                  l10n,
                  issue,
                ),
              );
            }),
          ),
        ],
      ),
      bottomNavigationBar: BottomActionBar(
        child: Obx(
              () => PrimaryButton(
            label: l10n.mapPickerConfirm,
            onPressed: _picker.canConfirm
                ? () => Get.back<PickedLocation>(
              result: _picker.point,
            )
                : null,
          ),
        ),
      ),
    );
  }
}