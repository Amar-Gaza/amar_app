import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../app/routes/app_routes.dart';
import '../../../app/routes/route_args.dart';

import '../../../controllers/customer/checkout_controller.dart';
import '../../../controllers/customer/map_picker_controller.dart';

import '../../../core/constants/app_defaults.dart';
import '../../../core/localization/location_issue_text.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/theme_context.dart';

import '../../../data/models/catalog/picked_location.dart';
import '../../../data/models/masar/masar_models.dart';
import '../../../data/services/shared/device_location_service.dart';

import '../../../l10n/app_localizations.dart';

import '../../widgets/checkout/bottom_action_bar.dart';
import '../../widgets/common/app_top_bar.dart';
import '../../widgets/common/error_banner.dart';
import '../../widgets/common/primary_button.dart';

/// Delivery point selection independent of saved-address loading.
class AddressPickerScreen extends StatefulWidget {
  const AddressPickerScreen({super.key});

  @override
  State<AddressPickerScreen> createState() =>
      _AddressPickerScreenState();
}

class _AddressPickerScreenState
    extends State<AddressPickerScreen> {
  final CheckoutController _checkout =
  Get.find<CheckoutController>();

  final DeviceLocationService _location =
  Get.find<DeviceLocationService>();

  late final String _tag =
      'delivery-point-${identityHashCode(this)}';

  late final MapPickerController _picker;
  late final Worker _follow;

  GoogleMapController? _map;

  bool _addingAddress = false;

  static const int _coordinateDigits = 5;

  @override
  void initState() {
    super.initState();

    final saved = _checkout.address.value;

    _picker = Get.put<MapPickerController>(
      MapPickerController(
        _location,
        saved == null
            ? _location.currentPoint.value
            : PickedLocation(
          lat: saved.lat,
          lng: saved.lng,
        ),
        autoLocate: false,
      ),
      tag: _tag,
    );

    _checkout.deliveryLocationFailure.value = null;

    _follow = ever<PickedLocation?>(
      _picker.located,
      _moveTo,
    );
  }

  Future<void> _moveTo(PickedLocation? point) async {
    final map = _map;

    if (!mounted || map == null || point == null) {
      return;
    }

    try {
      await map.animateCamera(
        CameraUpdate.newLatLngZoom(
          LatLng(point.lat, point.lng),
          AppDefaults.mapZoom,
        ),
      );
    } catch (_) {
      // Keep the selected coordinates if the map was disposed.
    }
  }

  void _selectPoint(PickedLocation point) {
    _checkout.deliveryLocationFailure.value = null;
    _picker.setPoint(point);
  }

  Future<void> _addAddress() async {
    if (_addingAddress ||
        _checkout.isSavingDeliveryLocation.value) {
      return;
    }

    setState(() => _addingAddress = true);

    try {
      // Select a marker location before entering address details.
      final picked = await Get.toNamed<PickedLocation>(
        AppRoutes.mapPicker,
        arguments: _picker.hasSelection.value
            ? _picker.point
            : null,
      );

      if (!mounted || picked == null) return;

      final saved = await Get.toNamed<Address>(
        AppRoutes.checkoutAddressNew,
        arguments: AddressFormArgs(
          point: picked,
        ),
      );

      if (!mounted || saved == null) return;

      _checkout.addAddress(saved);

      final point = PickedLocation(
        lat: saved.lat,
        lng: saved.lng,
      );

      _selectPoint(point);
      await _moveTo(point);
    } finally {
      if (mounted) {
        setState(() => _addingAddress = false);
      }
    }
  }

  Future<void> _confirm() async {
    if (!_picker.canConfirm ||
        _addingAddress ||
        _checkout.isSavingDeliveryLocation.value) {
      return;
    }

    final point = _picker.point;
    final resolved = _picker.address.value;
    final current = _checkout.address.value;

    Address? saved =
    current != null &&
        current.lat == point.lat &&
        current.lng == point.lng
        ? current
        : _checkout.addresses.firstWhereOrNull(
          (item) =>
      item.lat == point.lat &&
          item.lng == point.lng,
    );

    if (saved == null) {
      final resolvedLabel =
          resolved?.label.trim() ?? '';

      final label = resolvedLabel.isEmpty
          ? AppLocalizations.of(context).deliveryAddress
          : resolvedLabel;

      saved = await _checkout.saveDeliveryLocation(
        point: point,
        label: String.fromCharCodes(
          label.runes.take(
            AppDefaults.addressLabelMax,
          ),
        ),
        details: resolved?.label,
      );
    } else {
      _checkout.selectAddress(saved);
    }

    if (!mounted || saved == null) return;

    _location.confirmPoint(
      PickedLocation(
        lat: saved.lat,
        lng: saved.lng,
      ),
      address: resolved,
    );

    if (resolved == null) {
      unawaited(
        _location.setLanguage(
          _location.languageCode.value,
        ),
      );
    }

    Get.back<void>();
  }

  @override
  void dispose() {
    _follow.dispose();

    Get.delete<MapPickerController>(
      tag: _tag,
    );

    _map?.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final start = _picker.point;

    return Scaffold(
      appBar: AppTopBar(
        title: l10n.addressPickerTitle,
      ),
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Obx(
                        () => AbsorbPointer(
                      absorbing: _checkout
                          .isSavingDeliveryLocation
                          .value,
                      child: GoogleMap(
                        initialCameraPosition:
                        CameraPosition(
                          target: LatLng(
                            start.lat,
                            start.lng,
                          ),
                          zoom: AppDefaults.mapZoom,
                        ),
                        myLocationButtonEnabled: false,
                        zoomControlsEnabled: false,
                        onMapCreated: (map) {
                          _map = map;
                          _moveTo(_picker.point);
                        },
                        onTap: (point) {
                          _selectPoint(
                            PickedLocation(
                              lat: point.latitude,
                              lng: point.longitude,
                            ),
                          );
                        },
                        onLongPress: (point) {
                          _selectPoint(
                            PickedLocation(
                              lat: point.latitude,
                              lng: point.longitude,
                            ),
                          );
                        },
                        markers: {
                          if (_picker.hasSelection.value)
                            Marker(
                              markerId: const MarkerId(
                                'delivery-point',
                              ),
                              position: LatLng(
                                _picker.point.lat,
                                _picker.point.lng,
                              ),
                              draggable: true,
                              onDragStart: (_) {
                                _picker
                                    .beginManualSelection();
                              },
                              onDragEnd: (point) {
                                _selectPoint(
                                  PickedLocation(
                                    lat: point.latitude,
                                    lng: point.longitude,
                                  ),
                                );
                              },
                            ),
                        },
                      ),
                    ),
                  ),
                ),
                PositionedDirectional(
                  top: AppSpacing.md,
                  start: AppSpacing.lg,
                  end: AppSpacing.lg,
                  child: Obx(() {
                    final issue = _picker.issue.value;

                    return Material(
                      color: context.scheme.surface,
                      borderRadius: AppRadius.lgAll,
                      child: Padding(
                        padding: const EdgeInsets.all(
                          AppSpacing.md,
                        ),
                        child: Column(
                          mainAxisSize:
                          MainAxisSize.min,
                          crossAxisAlignment:
                          CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              _picker
                                  .address
                                  .value
                                  ?.label ??
                                  (_picker
                                      .isResolving
                                      .value
                                      ? l10n.addressLocating
                                      : l10n.addressPickOnMap),
                              style:
                              context.text.titleSmall,
                            ),
                            if (_picker
                                .hasSelection
                                .value)
                              Text(
                                '${_picker.point.lat.toStringAsFixed(_coordinateDigits)}, '
                                    '${_picker.point.lng.toStringAsFixed(_coordinateDigits)}',
                                textDirection:
                                TextDirection.ltr,
                                style:
                                context.text.labelSmall,
                              ),
                            if (_picker
                                .addressUnavailable
                                .value)
                              Text(
                                l10n
                                    .locationAddressUnavailable,
                              ),
                            if (issue != null) ...[
                              Text(
                                LocationIssueText.of(
                                  l10n,
                                  issue,
                                ),
                              ),
                              if (issue ==
                                  LocationIssue
                                      .deniedForever ||
                                  issue ==
                                      LocationIssue
                                          .serviceDisabled)
                                TextButton(
                                  onPressed:
                                  issue ==
                                      LocationIssue
                                          .serviceDisabled
                                      ? _picker
                                      .openLocationSettings
                                      : _picker.openSettings,
                                  child: Text(
                                    l10n
                                        .locationOpenSettings,
                                  ),
                                ),
                            ],
                          ],
                        ),
                      ),
                    );
                  }),
                ),
                PositionedDirectional(
                  bottom: AppSpacing.lg,
                  end: AppSpacing.lg,
                  child: Obx(
                        () => FilledButton.icon(
                      onPressed:
                      _picker.isLocating.value ||
                          _picker.isDragging.value ||
                          _checkout
                              .isSavingDeliveryLocation
                              .value
                          ? null
                          : _picker.locate,
                      icon: const Icon(
                        LucideIcons.locateFixed,
                      ),
                      label: Text(
                        _picker.isLocating.value
                            ? l10n.addressLocating
                            : l10n.addressUseMyLocation,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Obx(() {
            if (_checkout.addresses.isEmpty) {
              return const SizedBox.shrink();
            }

            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.lg,
              ),
              child: Row(
                children: [
                  for (final address
                  in _checkout.addresses)
                    Padding(
                      padding:
                      const EdgeInsetsDirectional.only(
                        end: AppSpacing.sm,
                      ),
                      child: ChoiceChip(
                        label: Text(
                          address.label ??
                              l10n.addressUse,
                        ),
                        selected:
                        _picker.hasSelection.value &&
                            address.lat ==
                                _picker.point.lat &&
                            address.lng ==
                                _picker.point.lng,
                        onSelected:
                        _checkout
                            .isSavingDeliveryLocation
                            .value
                            ? null
                            : (_) {
                          final point =
                          PickedLocation(
                            lat: address.lat,
                            lng: address.lng,
                          );

                          _selectPoint(point);
                          _moveTo(point);
                        },
                      ),
                    ),
                ],
              ),
            );
          }),
          Obx(
                () => TextButton.icon(
              onPressed:
              _checkout
                  .isSavingDeliveryLocation
                  .value ||
                  _addingAddress
                  ? null
                  : _addAddress,
              icon: const Icon(
                LucideIcons.plus,
              ),
              label: Text(
                l10n.addressAddNew,
              ),
            ),
          ),
          Obx(() {
            final failure =
                _checkout.addressesFailure.value;

            if (failure == null) {
              return const SizedBox.shrink();
            }

            return Row(
              children: [
                Expanded(
                  child: ErrorBanner(
                    failure: failure,
                  ),
                ),
                TextButton(
                  onPressed:
                  _checkout
                      .isLoadingAddresses
                      .value
                      ? null
                      : _checkout.loadAddresses,
                  child: Text(
                    l10n.commonRetry,
                  ),
                ),
              ],
            );
          }),
          Obx(() {
            final failure =
                _checkout
                    .deliveryLocationFailure
                    .value;

            return failure == null
                ? const SizedBox.shrink()
                : ErrorBanner(
              failure: failure,
            );
          }),
        ],
      ),
      bottomNavigationBar: BottomActionBar(
        child: Obx(
              () => PrimaryButton(
            label: l10n.addressUse,
            isLoading:
            _checkout
                .isSavingDeliveryLocation
                .value,
            onPressed:
            _picker.canConfirm &&
                !_addingAddress &&
                !_checkout
                    .isSavingDeliveryLocation
                    .value
                ? _confirm
                : null,
          ),
        ),
      ),
    );
  }
}